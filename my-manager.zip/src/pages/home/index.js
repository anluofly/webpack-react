import React from 'react'
import './index.less'

export default class Home extends React.Component {
    render() {
        return (
            <div className="home-wrap">
                欢迎回到home耶
            </div>
        )
    }
}