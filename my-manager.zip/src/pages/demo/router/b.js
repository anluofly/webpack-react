import React from 'react'


export default class B extends React.Component {
    render() {
        return <div>component B</div>;
    }
}