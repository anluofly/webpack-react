import React from 'react'
import './index.less'

export default class Footer extends React.Component {
    render() {
        return (
            <div className="footer">
                版权所有：小毛虫（推荐使用谷歌浏览器）
            </div>
        )
    }
}